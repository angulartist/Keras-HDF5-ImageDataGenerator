Keras HDF5 ImageDataGenerator
===============================

version number: 0.0.1
author: HDF5 ImageDataGenerator
status: Work in progress

Overview
--------

A dead simple Keras HDF5 ImageDataGenerator

Installation / Usage
--------------------

To install use pip:

    $ pip install hdf5generator


Or clone the repo:

    $ git clone https://github.com/angulartist/hdf5generator.git
    $ python setup.py install
    
Contributing
------------

TBD

Example
-------

TBD
=======
# Just a DEAD SIMPLE HDF5 files custom ImageGenerator

![](assets/generator.gif)
